cd
cd
rm -rf ~/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null



