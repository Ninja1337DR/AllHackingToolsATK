apt-get install git
apt-get install python
apt-get install future
apt-get install paramiko
apt-get install pysnmp
apt-get install pycrypto
cd
cd AllHackingTools
apt-get install python3-pip
git clone https://www.github.com/threat9/routersploit
cd routersploit
python3 -m pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/commixproject/commix.git commix     
cd commix
sudo python setup.py install
cd 
cd AllHackingTools 
git clone https://github.com/kuburan/txtool.git  
cd txtool   
./install.py 
cd 
cd 
cd AllHackingTools
git clone https://github.com/Moham3dRiahi/XAttacker.git
cd XAttacker
chmod +x termux-install.sh
bash termux-install.sh
cd
cd 
cd AllHackingTools
git clone https://github.com/karjok/fim
cd fim 
pip install -r requirements.txt
cd
cd
cd AllHackingTools
pip3 install future
