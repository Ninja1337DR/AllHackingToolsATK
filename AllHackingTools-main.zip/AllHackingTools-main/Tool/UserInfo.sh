cd && python AllHackingTools/Tool/UserInfo.py
